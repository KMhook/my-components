;'use strict';
(function() {
  PopMenu = function() {
    var testcase = [12,54353,5665,374,8,35,23,523,5,36,25,6,5463, 231, 67, 754];
    var i = 0;
    var $list = [];
    console.log(testcase);
    var size = testcase.length;
    for(;i < size; i ++) {
      $list.push($('<div>' + testcase[i] + '</div>'));
    }

    var mGalleryItemRepository = new GalleryItemRepository($list, 5);
    var mGalleryView = new GalleryView(mGalleryItemRepository, $('#gallery-parent'));
    var mGalleryController = new GalleryController(mGalleryItemRepository, mGalleryView);

    document.addEventListener('keydown', function(e) {
      mGalleryView.keyEventHandler(e);
    });
  };

  PopMenu.prototype = {

  };

  var popMenu = new PopMenu();
})();

