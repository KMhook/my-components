;'use strict';
(function() {

  var KEY_CODE = {
    KEY_ENTER: 13,
    KEY_ARROW_LEFT: 37, 
    KEY_ARROW_UP: 38,
    KEY_ARROW_RIGHT: 39,
    KEY_ARROW_DOWN: 40,
    KEY_ESCAPE: 27
  };

  /*
   * constructor
   * @param {Array} contents 
   * @param {Object} $parent
   * @param {Object} config
   */
  GalleryView = function(repository, $parent, config) {
    BaseView.call(this);
    this.$parent = $parent;
    this.config = config;
    this.$root = $('<div></div>');
    this.$root.addClass('gallery-root');
    //this.contents = contents;
    this.repository = repository;

    this._watchModel();
    this._reRender();
  };

  GalleryView.prototype = Object.assign(new BaseView(), {
    /*
     * 监听model中成员的变化
     */
    _watchModel: function() {
      this.repository.watch('currentFocusItemIndex', function() {
        this._setFocus();
      }.bind(this));
      this.repository.watch('queriedPages', function(pages) {
        this._updateContents(pages);
      });
    },
    keyEventHandler: function(e) {
      if(e.type == 'keydown') {
        var keyCode = e.keyCode;
        switch(keyCode) {
          case 37:
            this.prevFocus();
            break;
          case 39:
            this.nextFocus();
            break;
          default: 
            break;
        }
      }
    },
    _reRender: function() {
      var i = 0;
      var contentsLength = this.contents.length;
      for(;i < contentsLength; i ++ ) {
        this.$root.append(this.contents[i]);
      }
      this.$parent.append(this.$root);
    },
    /*
     * 更新gallery中的内容
     * @param {Array} contents
     */
    _updateContents: function(contents) {
      this.contents = contents;
    },
    _setFocus: function() {
    },
    prevFocus: function() {
      this.trigger('prev');
    },
    nextFocus: function() {
      this.trigger('next');
    },
  });
  GalleryView.prototype.constructor = GalleryView;
})();

