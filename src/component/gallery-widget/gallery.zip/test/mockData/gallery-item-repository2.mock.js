var testcase = {
  items: [1, 2, 3, 4, 5], //23 items
  selectIndex: 2
};

exports.testcase = testcase;
