;(function() {
  GalleryModel = function() {
    BaseModel.call(this);
    this. = null;
  };

  GalleryModel.prototype = Object.create(BaseModel, {
    constructor: GalleryModel,

  });
})();

